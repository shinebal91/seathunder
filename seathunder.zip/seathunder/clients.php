<!DOCTYPE html>

<html lang="en">
    
    <head>
	<title>SeaThunder Clients</title>

<?php

include 'header.php';

?>

        <!-- Client section start -->
        <div id="clients">
            <div class="section primary-section">
                <!--div class="triangle"></div-->
                <div class="container">
                    <div class="title">
                        <h1>What Client Say?</h1>
                        <p>We provide THE BEST QUALITY services to our clients.</p>
                    </div>
                    <div class="row">
                        <div class="span4">
                            <div class="testimonial">
                                <p>"SeaThunder members have done a GREAT JOB in handling the shipment. The whole procedure was handled in a very precise and professional manner."</p>
                                <div class="whopic">
                                    <div class="arrow"></div>
                                    <img src="images/Client1.png" style="width:200px; height:200px;" class="centered" alt="client 1">
                                    <strong>Dell Co.
                                        <small>Client</small>
                                    </strong>
                                </div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="testimonial">
                                <p>"Great thanks to all of you for your hard efforts from the day one on accepting this perishable shipment and finally making it a great success."</p>
                                <div class="whopic">
                                    <div class="arrow"></div>
                                    <img src="images/Client4.png" style="width:200px; height:200px;" class="centered" alt="client 2">
                                    <strong>Alphonso Mango
                                        <small>Client</small>
                                    </strong>
                                </div>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="testimonial">
                                <p>"The Service provided was first class and we are satisfied with their Work and Quality of Staff. We hope their same endeavour will remain and congratulate them on achieving the task with flying colours."</p>
                                <div class="whopic">
                                    <div class="arrow"></div>
                                    <img src="images/Client8.png" style="width:200px; height:200px;" class="centered" alt="client 3">
                                    <strong>Fiesta Dinnerware
                                        <small>Client</small>
                                    </strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--p class="testimonial-text">
                        "Perfection is Achieved Not When There Is Nothing More to Add, But When There Is Nothing Left to Take Away"
                    </p-->
                </div>
            </div>
        </div>
        <div class="section third-section">
            <div class="container centered">
                <div class="sub-section">
                    <div class="title clearfix">
                        <div class="pull-left">
                            <h3 style="color:#fff;">Our Clients</h3>
                        </div>
                        <ul class="client-nav pull-right">
                            <li id="client-prev"></li>
                            <li id="client-next"></li>
                        </ul>
                    </div>
                    <ul class="row client-slider" id="clint-slider">
                        <li>
                            
                                <img src="images/clients/ClientLogo01.png" style="width:400px; height:200px;" alt="client logo 1">
                            
                        </li>
                        <li>
                            
                                <img src="images/clients/ClientLogo04.png" style="width:400px; height:200px;" alt="client logo 4">
                            
                        </li>
                        <li>
                            
                                <img src="images/clients/ClientLogo08.png" style="width:400px; height:200px;" alt="client logo 8">
                            
                        </li>
                        <li>
                            
                                <img src="images/clients/ClientLogo03.png" style="width:400px; height:200px;" alt="client logo 3">
                            
                        </li>
						<li>
                            
                                <img src="images/clients/ClientLogo07.png" style="width:400px; height:200px;" alt="client logo 7">
                            
                        </li>
                        <li>
                            
                                <img src="images/clients/ClientLogo02.png" style="width:400px; height:200px;" alt="client logo 2">
                            
                        </li>
                        <li>
                            
                                <img src="images/clients/ClientLogo05.png" style="width:400px; height:200px;" alt="client logo 5">
                            
                        </li>
                        <li>
                            
                                <img src="images/clients/ClientLogo08.png" style="width:400px; height:200px;" alt="client logo 8">
                            
                        </li>
                    </ul>
                </div>
            </div>
        </div>

<?php
include 'footer.php';

?>
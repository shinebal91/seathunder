<!-- Footer section start -->
        <div id="footer" >
			<div class="row-fluid">
			<a href="../home.php"><img src="../images/logo_bw.png"  alt="SeaThunder Logistics" align="left" style="width:500px; height:80px; vertical-align:middle;"></a>
			</div>
			<br>
			<div class="row-fluid">
				<div class="span2"></div>
				<div class="span3">
					<ul>
						<li><a href="../home.php" style="font-size:16px;">Home</a></li>
						<li><a href="../services.php" style="font-size:16px;">Services</a></li>
						<li><a href="../fleet.php" style="font-size:16px;">Fleet</a></li>
						<li><a href="../clients.php" style="font-size:16px;">Clients</a></li>
						<li><a href="contact-us.php" style="font-size:16px;">Contact Us</a></li>
						<li><a href="feedback.php" style="font-size:16px;">Feedback</a></li>
						<!--li><a href="../track.php" style="font-size:16px;">Track</a></li>
						<li><a href="../login.php" style="font-size:16px;">Login</a></li>
						<li><a href="../signup.php" style="font-size:16px;">Signup</a></li-->
					</ul>
				</div>
				<div class="span3">
					<ul>
						<li><a href="home.php" style="font-size:16px;">My Home</a></li>
						<li><a href="consignment.php" style="font-size:16px;">My Consignments</a></li>
						<li><a href="track.php" style="font-size:16px;">Track My Consignment</a></li>
						<li><a href="account.php" style="font-size:16px;">My Account</a></li>
						<li><a href="../logout.php" style="font-size:16px;">Logout</a></li>
					</ul>
				</div>
				<div class="span3">
					<ul>
						<li style="font-size:16px;">SEBIZ SQUARE</li>
						<li style="font-size:16px;">Plot No. IT-C6,	I.T.Park, Sector-67,</li>
						<li style="font-size:16px;">Sahibzada Ajit Singh Nagar,</li>
						<li style="font-size:16px;">Punjab 160062</li>
						<li style="font-size:16px;">seathunder.logistics@gmail.com</li>
						<li style="font-size:16px;">+91-172-306-8070</li>
					</ul>
				</div>
				<div class="span1">
				</div>
			</div>
			<div class="row-fluid" style="margin-left:10px; padding-top:1%;">	
				<span style="color:#B8B8B8;">2015 &copy; <a href="../home.php">SeaThunder Logistics.</a> All Rights Reserved.</span>
			</div>
			
        </div>
        <!-- Footer section end -->
   
   
				<!-- ScrollUp button start -->
				<div class="scrollup">
					<a href="#">
						<i class="icon-chevron-up"></i>
					</a>
				</div>
				<!-- ScrollUp button end -->
   
   
   <!-- BEGIN JAVASCRIPTS -->    
   <!-- Load javascripts at bottom, this will reduce page load time >
   <script src="../configurations/js/jquery-1.8.3.min.js"></script-->
   <script src="../configurations/assets/bootstrap/js/bootstrap.min.js"></script>
   <script src="../configurations/js/jquery.blockui.js"></script>
   <!-- ie8 fixes -->
   <!--[if lt IE 9]>
   <script src="../configurations/js/excanvas.js"></script>
   <script src="../configurations/js/respond.js"></script>
   <![endif]-->
   
   <script type= "text/javascript" src ="countries3.js"></script>
   
   <script type="text/javascript" src="../configurations/assets/chosen-bootstrap/chosen/chosen.jquery.min.js"></script>
   <script type="text/javascript" src="../configurations/assets/uniform/jquery.uniform.min.js"></script>
   <script type="text/javascript" src="../configurations/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="../configurations/assets/data-tables/DT_bootstrap.js"></script>
   
   <script src="../configurations/assets/jqvmap/jqvmap/jquery.vmap.js" type="text/javascript"></script>
	<script src="../configurations/assets/fancybox/source/jquery.fancybox.pack.js"></script>
	
	
	<script src="../configurations/js/scripts.js"></script>
	
	
   
   <script>
      jQuery(document).ready(function() {       
         // initiate layout and plugins
         App.init();
		print_country("from_country");
		print_country("to_country");
		//jQuery("#tracktable").hide();
		
		
		//scroll to top
		
			//Check to see if the window is top if not then display button
			jQuery(window).scroll(function(){
				if (jQuery(this).scrollTop() > 50) {
					jQuery('.scrollup').fadeIn();
				} else {
					jQuery('.scrollup').fadeOut();
				}
			});
	
			/*Click event to scroll to top
			jQuery('.scrollup').click(function(){
				jQuery('html, body').animate({scrollTop : 0},800);
				return false;
			});*/
		//scroll to top end

		
      });
   </script>
   <!-- END JAVASCRIPTS -->   
</body>
<!-- END BODY -->
</html>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>My Account</title>
   
<?php
$group_id=2;
include 'header.php';
?>

      
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     My Account
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="account.php">My Account</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
					<div class="span2"></div>
				
				<div class="span2 zoom-in">
				<a class="brand" href="home.php">
                   <center>
				   <img src="../images/company/Home.png" alt="Home"/>
				   <br><br>
				   <span><strong>HOME</strong></span>
				   </center>
				</a>
				</div>
				
				<div class="span2 zoom-in">
				<a class="brand" href="profile.php">
                   <center>
				   <img src="../images/company/User Male2.png" alt="View Profile"/>
				   <br><br>
				   <span><strong><center>VIEW PROFILE</center></strong></span>
				   </center>
				</a>
				</div>
				
				<div class="span2 zoom-in">
				<a class="brand" href="edit-profile.php">
                   <center>
				   <img src="../images/company/Edit User Filled.png" alt="Edit Profile"/>
				   <br><br>
				   <span><strong><center>EDIT PROFILE</center></strong></span>
				   </center>
				</a>
				</div>
			
				<div class="span2 zoom-in">
				<a class="brand" href="reset-password.php">
                   <center>
				   <img src="../images/company/Safe Filled.png" alt="Reset Password"/>
				   <br><br>
				   <span><strong><center>RESET PASSWORD</center></strong></span>
				   </center>
				</a>
				</div>
						
				<div class="span2"></div>
               </div>
            </div>
			<br>
			<div class="row-fluid">
               <div class="span12">
					<div class="span2"></div>
					
				<div class="span2 zoom-in">
				<a class="brand" href="contact-us.php">
                   <center>
				   <img src="../images/company/Contact Card Filled.png" alt="Contact Us"/>
				   <br><br>
				   <span><strong><center>CONTACT US</center></strong></span>
				   </center>
				</a>
				</div>
				
				<div class="span2 zoom-in">
				<a class="brand" href="feedback.php">
                   <center>
				   <img src="../images/company/Feedback_2.png" alt="Feedback"/>
				   <br><br>
				   <span><strong><center>FEEDBACK</center></strong></span>
				   </center>
				</a>
				</div>
			
				<div class="span2 zoom-in">
				<a class="brand" href="../logout.php">
                   <center>
				   <img src="../images/company/Logout.png" alt="Logout"/>
				   <br><br>
				   <span><strong><center>LOGOUT</center></strong></span>
				   </center>
				</a>
				</div>
				
					<div class="span2"></div>
               </div>
            </div>
			
			
			
			
			
            <!-- END PAGE CONTENT-->         
         </div>
         <!-- END PAGE CONTAINER-->
      </div>
      <!-- END PAGE -->  
   </div>
   <!-- END CONTAINER -->
   
   
<?php

include 'footer.php';

?>
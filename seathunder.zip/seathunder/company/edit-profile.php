<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>Edit Profile</title>
   

<?php
$group_id=2;
include 'header.php';
?>


         
<script src="../js/jquery.form.min.js"></script>

<script src="../js/imgchk.js"></script>



         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     Edit Profile
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="account.php">My Account</a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="profile.php">My Profile</a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="edit-profile.php">Edit Profile</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->


 <!-- BEGIN PAGE CONTENT: PROFILE-->
            <div class="row-fluid">
				<div class="span12">
					<div class="widget">
                        <div class="widget-title">
                           <h4><i class="icon-pencil"></i> Edit Profile</h4>
                           <span class="tools">
                           <a href="javascript:;" class="icon-chevron-down"></a>
                           <a href="javascript:;" class="icon-remove"></a>
                           </span>                    
                        </div>
                        <div class="widget-body">
						
							
							<?php $fetch_profile ="SELECT * from members where user_id=".$_SESSION['user_id'];
									$fetch_profile_res =execute($fetch_profile);
										while($profile_detail = mysqli_fetch_array($fetch_profile_res,MYSQLI_ASSOC))
										{
																				
										?>
                            <div class="span3">
								
                                <div class="text-center profile-pic">
                                    <center><img src="images/profiles/<?php echo $profile_detail['logo']; ?>" alt="Profile Image"></center>
                                </div>
								
                                <ul class="nav nav-tabs nav-stacked">
                                    <li>
									<div class="">
									<!--h5>Select Profile Picture</h5-->
									
									<form action="processupload.php" method="post" enctype="multipart/form-data" id="MyUploadForm">
									<center><input name="FileInput" id="FileInput" type="file" class="btn btn-warning disabled" />&nbsp;<br>
									<input type="submit"  id="submit-btn" value="Upload"  class="btn btn-success"/>&nbsp;</center>
									<img src="../configurations/img/loading.gif" id="loading-img" style="display:none;" alt="Please Wait"/>
									</form>
									</div>

									<!--<a type="file" class="btn btn-info" name="fileToUpload" id="fileToUpload"><i class="icon-upload-alt"></i> Upload Company Logo</a></li>
									
									<!--input type="file" name="fileToUpload" id="fileToUpload"-->
                                </ul>
								
                            </div>
							
							<div class="span1"></div>
							
							<form id="edit_profile_form" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
							
                            <div class="span7" id="profile">
                                <h4>Company Profile<br/><small></small></h4>
								
                                <table class="table table-borderless">
                                    <tbody>
									
                                    <tr>
                                        <td>Full Name :</td>
                                        <td>
                                            <input type="text" name="fname" id="fname" value="<?php echo $profile_detail['fname']; ?>">
                                        </td>
										                                        <td>
                                            <input type="text" name="lname" id="lname" value="<?php echo $profile_detail['lname']; ?>">
                                        </td>

                                    </tr>
									<tr>
                                        <td class="span3">Email :</td>
                                        <td>
                                            <input type="email" name="email" id="email" value="<?php echo $profile_detail['email']; ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="span3">Company Name :</td>
                                        <td>
                                            <input type="text" name="cname" id="cname" value="<?php echo $profile_detail['company']; ?>">
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span3">Website :</td>
                                        <td>
                                            <input type="text" name="website" id="website" value="<?php echo $profile_detail['website']; ?>">
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span3">Contact No. :</td>
                                        <td>
                                            <input type="number" name="contact" id="contact" value="<?php echo $profile_detail['contact']; ?>">
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
								<h4>Address</h4>
                                <div class="well">
                                    <address>
										<table>
											<tbody>
											<tr>
												<td>Address</td><td> : </td><td><input type="text" name="address" id="address" value="<?php echo $profile_detail['address']; ?>"></td>
											</tr>
											<tr>
												<td>Country</td><td> : </td><td>
												<input type="hidden" value="<?php echo $profile_detail['country'];?>" id="cntry">
												<select name="country" id="country" onchange="print_state('state', this.selectedIndex);"><option value="<?php echo $profile_detail['country'];?>"><?php echo $profile_detail['country'];?><option></select>
												</td>
											</tr>
											<tr>
												<td>State</td><td> : </td><td><select name ="state" id ="state"><option value="<?php echo $profile_detail['state'];?>"><?php echo $profile_detail['state'];?><option></select></td>
											</tr>
											<tr>
												<td>City</td><td> : </td><td><input type="text" name="city" id="city" value="<?php echo $profile_detail['city']; ?>"></td>
											</tr>
											<tr>
												<td>Zipcode</td><td> : </td><td><input type="number" name="zip" id="zip" value="<?php echo $profile_detail['zip']; ?>"></td>
											</tr>
																						
											</tbody>
										</table>
                                    </address>
                                </div>
								
								<ul class="nav nav-tabs nav-stacked ">
										<li><center>
											<a class="btn btn-info span4" id="save-btn"><i class="icon-ok"></i> Save</a>
										</center></li>
									</ul>
									
								
                            </div>
							
							<?php } ?>
					
                            <div class="space5"></div>
                        </div>
					</div>
				</div>
            </div>
            <!-- END PAGE CONTENT: PROFILE-->         
			</div>
         <!-- END PAGE CONTAINER-->
      </div>
      <!-- END PAGE -->  
   </div>
   <!-- END CONTAINER -->
<script>
$('#country').mouseenter(function()
{ 
print_country("country");
});
/*
$('#country').mouseout(function()
{ 
var old=$('#cntry').val();
$('#country').html("<option value="+old+">"+old+"</option>");
if($('#country option:selected').text()==old)
{
	$('#country').html("<option value="+old+">"+old+"</option>");
}

});*/


var form_modified = false ;
$(':input').on('change',function()
{ 
form_modified=true;
});
$('select').on('change',function()
{ 
form_modified = true;
});
$('#save-btn').click(function (){
	

if(form_modified == true)
{
	var datastr="profile=update&firstname=" + jQuery("#fname").val() + "&lname="+jQuery('#lname').val()+"&cname="+ jQuery("#cname").val() + "&website="+ jQuery("#website").val() + "&contact="+ jQuery('#contact').val() + "&address="+ jQuery('#address').val() + "&country="+ jQuery("#country").val()  + "&state="+ jQuery("#state").val() +  "&city="+ jQuery("#city").val() + "&zip="+ jQuery("#zip").val() + "&email=" + jQuery("#email").val()  ;
	 jQuery.ajax({
	 type:'POST',
	 data:datastr,
	 url:'controller.php',
	 success: function(data) { 
	 if(data == 200)
	 {
	 jQuery('#save-btn').html("Updated");
	 jQuery('#save-btn').prop('disabled', true);
	 //jQuery('#modal3-trigger').trigger("click");
	 
	 }
	 else
	 {
	alert("Some Error Occured. Please Try Again Or Contact Administrator");  
	 //alert(data);
	 }
	 }
	 
	 });

	
} 
});
/*
jQuery('#submit-btn').click(function(){ 
var datastr=jQuery("#FileInput").val() ;
	 jQuery.ajax({
	 type:'POST',
	 data:datastr,
	 url:'processupload.php',
	 success: function(data) { }
});


  }); */
  </script>
	
<?php

include 'footer.php';
//include 'processupload.php';





// Check if file already exists


?>
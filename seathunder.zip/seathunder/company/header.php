<!DOCTYPE html>

<html lang="en">
    
    <head>
	
	<title>My SeaThunder</title>
	
<?php
$group_id=2;
include '../auth.php';
include 'controller.php';
?>
	
   <meta charset="utf-8" />
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <meta content="" name="description" />
   <meta content="" name="author" />
   
   <script src="../configurations/js/jquery-1.8.3.min.js"></script>
   
   <!-- Load Roboto font -->
        <link href="http://fonts.googleapis.com/css?family=Roboto:400,300,700&amp;subset=latin,latin-ext" rel='stylesheet' type='text/css'>
   
   <link href="../configurations/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="../configurations/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="../configurations/assets/bootstrap/css/bootstrap-fileupload.css" rel="stylesheet" />
   <link href="../configurations/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   
   <link href="../configurations/css/style.css" rel="stylesheet" />
   <link href="../configurations/css/style_responsive.css" rel="stylesheet" />
   <link href="../configurations/css/style_default.css" rel="stylesheet" id="style_color" />

   <link href="../configurations/assets/fancybox/source/jquery.fancybox.css" rel="stylesheet" />
   <link rel="stylesheet" type="text/css" href="../configurations/assets/uniform/css/uniform.default.css" />
   
   <!-- Fav and touch icons -->
		<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">
		<link rel="icon" href="../images/favicon.ico" type="image/x-icon"></link>  
   
   
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="fixed-top">
   <!-- BEGIN HEADER -->
   <div id="header" class="navbar navbar-inverse navbar-fixed-top">
       <!-- BEGIN TOP NAVIGATION BAR -->
       <div class="navbar-inner">
           <div class="container-fluid">
               <!-- BEGIN LOGO -->
               <a class="brand" href="../home.php">
                   <img src="../configurations/img/logo.png" alt="SeaThunder Logistics" />
               </a>
               <!-- END LOGO -->
               <!-- BEGIN RESPONSIVE MENU TOGGLER -->
               <a class="btn btn-navbar collapsed" id="main_menu_trigger" data-toggle="collapse" data-target=".nav-collapse">
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="arrow"></span>
               </a>
               <!-- END RESPONSIVE MENU TOGGLER -->
               <div id="top_menu" class="nav notify-row">
                   <!-- BEGIN NOTIFICATION -->
                   <ul class="nav top-menu ">
				   
					 <!-- BEGIN my home >
                        <li class="dropdown">
                            <a class="dropdown-toggle element" data-placement="bottom" data-toggle="tooltip" href="home.php" data-original-title="Settings">
                                <i class="icon-home"></i>
                            </a>
                        </li>
                        <!-- END my home -->
				   
					   <?php
					   
					   //include 'inbox.php';
					   //include 'notification.php';
					   
					   ?>
				   </ul>
               </div>
               <!-- END  NOTIFICATION -->
			   
			   
               <div class="top-nav ">
                   <ul class="nav pull-right top-menu" >
                       <!-- BEGIN USER LOGIN DROPDOWN -->
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                               <img src="images/profiles/<?php echo $_SESSION['dp'];?>" style="width:40px; height:40px; vertical-align:middle;" alt="Profile Image">
                               <span class="username" style="vertical-align:middle;"><?php echo $_SESSION['user_name']; ?></span>
                               <i class="icon-caret-down" style="vertical-align:middle;"></i>
                           </a>
                           <ul class="dropdown-menu">
							   <li><a href="home.php"><i class="icon-home"></i> My Home</a></li>
							   <li><a href="consignment.php"><i class="icon-shopping-cart"></i> My Consignments</a></li>
                               <li><a href="account.php"><i class="icon-cogs"></i> My Account</a></li>
                               <li class="divider"></li>
                               <li><a href="../logout.php"><i class="icon-signout"></i> LOGOUT</a></li>
                           </ul>
                       </li>
                       <!-- END USER LOGIN DROPDOWN -->
                   </ul>
                   <!-- END TOP NAVIGATION MENU -->
				   
               </div>
           </div>
       </div>
       <!-- END TOP NAVIGATION BAR -->
   </div>
   <!-- END HEADER -->
   
   
   <!-- BEGIN CONTAINER -->
   <div id="container" class="row-fluid ">
      <!-- BEGIN SIDEBAR -->
      <div id="sidebar" class="nav-collapse collapse">

         <div class="sidebar-toggler hidden-phone"></div>   

         <!-- BEGIN RESPONSIVE QUICK SEARCH FORM >
         <div class="navbar-inverse">
            <form class="navbar-search visible-phone">
               <input type="text" class="search-query" placeholder="Search" />
            </form>
         </div>
         <!-- END RESPONSIVE QUICK SEARCH FORM -->
		 
		 
         <!-- BEGIN SIDEBAR MENU -->
          <ul class="sidebar-menu">
		  
			  <li class="has-sub">
                  <a href="javascript:;" class="" style="padding: 0px; margin:0px;">
                      <span class="icon-box"> <i class="icon-shopping-cart"></i></span>My Consignments
                      <span class="arrow"></span>
				  </a>
				  <ul class="sub">
                      <li><a class="" href="add-consignment.php" style="padding-left: 20px;"><span class="icon-box" style="padding: 10px;"><i class="icon-plus"></i></span>ADD NEW</a></li>
					  <li><a class="" href="view-consignment.php" style="padding-left: 20px;"><span class="icon-box" style="padding: 10px;"><i class="icon-list-alt"></i></span>VIEW ALL</a></li>
                  </ul>
              </li>
			  
			  <li class="has-sub">
                  <a href="track.php" class="">
                      <span class="icon-box"><i class="icon-map-marker"></i></span>Track Consignment
                      <!--span class="arrow"></span-->
                  </a>
              </li>
			  
			  <li class="has-sub">
                  <a href="javascript:;" class="" style="padding: 0px; margin:0px;">
                      <span class="icon-box"> <i class="icon-cogs"></i></span>My Account
                      <span class="arrow"></span>
				  </a>
				  <ul class="sub">
                      <li><a class="" href="profile.php" style="padding-left: 20px;"><span class="icon-box" style="padding: 10px;"><i class="icon-user"></i></span>MY PROFILE</a></li>
					  <li><a class="" href="reset-password.php" style="padding-left: 20px;"><span class="icon-box" style="padding: 10px;"><i class="icon-lock"></i></span>RESET PASSWORD</a></li>
                  </ul>
              </li>
		  		  
              <li class="has-sub">
                  <a href="../logout.php" class="">
                      <span class="icon-box"><i class="icon-signout"></i></span>LOGOUT
                      <!--span class="arrow"></span-->
                  </a>
              </li>
          </ul>
         <!-- END SIDEBAR MENU -->
      </div>
      <!-- END SIDEBAR -->
      
	  
	  
	  <!-- BEGIN PAGE -->  
      <div id="main-content" style="min-height: 400px;">
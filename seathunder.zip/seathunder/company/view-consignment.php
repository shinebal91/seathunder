<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>View All Consignments</title>

<?php
$group_id=2;
include 'header.php';
?>


         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     My Consignments
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="consignment.php">My Consignments</a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="view-consignment.php">View All</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->


 			
			
			<!--consignment table-->
			<div class="row-fluid">
				<div class="span12">
						<div class="widget">
				<div class="widget-title">
					<h4><i class="icon-list"></i> View All Consignments</h4>
					<span class="tools">
						<a class="icon-chevron-down" href=""></a>
						<a class="icon-remove" href=""></a>
					</span>
				</div>
				<div class="widget-body" style="display:block;">
					
					<table class="table table-striped table-bordered" id="sample_1">
                            <thead>
                                <tr>
                                    
									<th class="span2">CONSIGNMENT ID</th>
                                    <th class="span2">FROM</th>
                                    <th class="span2">TO</th>
                                    <th class="span2">ACTION</th>
									<th class="span2">STATUS</th>
                                </tr>
                            </thead>
                            <tbody id="consignment_grid">
								<?php $fetch_cons ="SELECT cons_id,from_country,to_country,is_complete from consignments where user_id=".$_SESSION['user_id'];
									$fetch_cons_res =execute($fetch_cons);
										while($cons_detail = mysqli_fetch_array($fetch_cons_res))
										{
																				
										?>

							  <tr class="odd gradeX">
                                    
									<td><?php echo "SEA00".$_SESSION['user_id']."00".$cons_detail['cons_id']; ?></td>
                                    <td><?php echo $cons_detail['from_country']; ?></td>
                                    <td><?php echo $cons_detail['to_country']; ?></td>
									
                                    <td>
									<button id="view-btn<?php echo $cons_detail['cons_id'];?>"  onclick="viewer(<?php echo $cons_detail['cons_id'];?>);" class="btn btn-warning" data-toggle="modal" data-target="#myModal1"><i class="icon-eye-open"></i> View</button>&nbsp;
									
									<a role="button" href="invoice.php?invcid=<?php echo $cons_detail['cons_id']; ?>" id="invoice-btn" class="btn btn-inverse"><i class="icon-file"></i> Invoice</a>
									</td>
									
									<td><?php if($cons_detail['is_complete']==1)echo "<span class='btn btn-success' disabled >Completed</span>"; else echo "<span class='btn btn-warning' disabled>In-Complete</span> <a class='btn btn-primary' role='button'  href='track.php?cons_status=SEA00".$_SESSION['user_id']."00".$cons_detail['cons_id']."'>Check Status</a>"; ?>
									</td>
							   </tr>
								<?php } ?>
                                </tbody>
								
                        </table>
						
				</div>
			</div>			  
	</div>
			
			
			</div>
            <!-- END PAGE CONTENT: consignment table-->         
			</div>
         <!-- END PAGE CONTAINER-->
      </div>
      <!-- END PAGE -->  
	  
	  
	  <!-- View Consignment Modal -->
  <div id="myModal1" style="width:65%; height:auto; margin-left:-32%;" class="modal hide fade " role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
		
		<div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 id="myModalLabel1"><i class="icon-list"></i>&nbsp;CONSIGNMENT DETAILS</h3>
        </div>
	  
		
        <div class="modal-body">
		  <div class="span1"></div>
          <div class="span10">
                                <h4>Consignment ID : <?php echo "SEA00".$_SESSION['user_id']."00<span id='resp-conssid'></span>"; ?><br/><small></small></h4>
                                <table class="table table-borderless">
                                    <tbody>
									
                          <tr>
                                  <td class="span2">Content : </td>
                               <td colspan=3><span id="resp-content"></span>                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2">Total Units : </td>
                                        <td>
               <span id="resp-units"></span>                                       </td>
										<td class="span2">Weight (in Kgs.) : </td>
                                        <td>
                                   <span id="resp-weight"></span>                                       </td>
                                    </tr>
									<tr>
                                        <td class="span2">Contains perishable item? </td>
                                        <td>
                                           <span id="resp-perish"></span>                              </td>
										<td class="span2">Contains fragile item? </td>
                                        <td>
                                            <span id="resp-fragile"></span>                     </td>
                                    </tr>
									<tr>
                                        <td class="span2">Sender : </td>
                                        <td>
                                           <span id="resp-sender"></span>                                 </td>
										<td class="span2">Receiver : </td>
                                        <td>
                                         <span id="resp-receiver"></span>                               </td>
                                    </tr>
									<tr>
										<td class="span2">Address : </td>
                                        <td>
                                            <span id="resp-saddress"></span>                                    </td>
										
										<td class="span2">Address : </td>
                                        <td>
                                            <span id="resp-raddress"></span>                                 </td>
									</tr>
									<tr>
										<td class="span2">Country : </td>
										<td><span id="resp-scountry"></span></td>
										
										<td class="span2">Country : </td>
										<td><span id="resp-rcountry"></span></td>
									</tr>
									<tr>
										<td class="span2">State : </td>
										<td><span id="resp-sstate"></span></td>
                                        
										<td class="span2">State : </td>
										<td><span id="resp-rstate"></span></td>
									</tr>
									<tr>
                                        <td class="span2">City : </td>
                                        <td>
                                            <span id="resp-scity"></span>                           </td>
										<td class="span2">City : </td>
                                        <td>
                                            <span id="resp-rcity"></span>                          </td>
                                    </tr>
									<tr>
                                        <td class="span2">Zipcode : </td>
                                        <td>
                                            <span id="resp-szip"></span>                                       </td>
										<td class="span2">Zipcode : </td>
                                        <td>
                                            <span id="resp-rzip"></span>                           </td>
                                    </tr>
									
                                    </tbody>
								</table>
		  </div>
		  <div class="span1"></div>
		</div><!--modal body-->
		
		
        <div class="modal-footer">
          <button type="button" class="btn btn-inverse" data-dismiss="modal" aria-hidden="true">Close</button>
        </div>
		
		</div><!--modal content-->
      
   </div>
   <!-- END CONTAINER -->
		
<script>

function viewer(sa)
	 {
	 var modalid=".modal-body "
	 var datastr = 'cons_method=view&cons_id='+sa;
	 jQuery.ajax({
	 type:'POST',
	 data:datastr,
	 url: 'controller.php',
	 success: function(data) { response(data) ;   }
	 });
	 
	 
	 }
	 
function response(data)
	 {
	var obj= jQuery.parseJSON(data);
		jQuery('#resp-conssid').text(obj.cons_id);
		jQuery('#resp-content').text(obj.content);
		jQuery('#resp-units').text(obj.units);
		jQuery('#resp-perish').text(obj.perishable);
jQuery('#resp-fragile').text(obj.fragile);	
	if(jQuery('#resp-perish').text()==1)
		{
			jQuery('#resp-perish').text("Yes");
		}
		else
		{
			jQuery('#resp-perish').text("No");
			}
			
		if(jQuery('#resp-fragile').text()==1)
		{
			jQuery('#resp-fragile').text("Yes");
			}
			else
			{
				jQuery('#resp-fragile').text("No");
				}
		jQuery('#resp-weight').text(obj.weight_kg);
		jQuery('#resp-sender').text(obj.sender);
		jQuery('#resp-receiver').text(obj.receiver);
		jQuery('#resp-saddress').text(obj.from_address);
		jQuery('#resp-raddress').text(obj.to_address);
		jQuery('#resp-scountry').text(obj.from_country);
		jQuery('#resp-rcountry').text(obj.to_country);
		jQuery('#resp-sstate').text(obj.from_state);
		jQuery('#resp-rstate').text(obj.to_state);
	jQuery('#resp-scity').text(obj.from_city);
		jQuery('#resp-rcity').text(obj.to_city);
			jQuery('#resp-szip').text(obj.from_zip);
		jQuery('#resp-rzip').text(obj.to_zip);
		
		
	 }

</script>	

<?php

include 'footer.php';

?>

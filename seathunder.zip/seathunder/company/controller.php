<?php

include('../config.php');

$group_id=2;
//include('../auth.php');

function execute($sql)
{
$res = mysqli_query($GLOBALS['connect'],$sql);
return $res;
}

function get_cons_charge($weight)
{
//25 rs per kg
return (($weight*25) + ((1/10) * ($weight*25))); 
}

function get_payment_detail($cons_id,$user_id)
{
	$sql="SELECT * from payments where cons_id=".$cons_id." and user_id=".$user_id ;
	$res=execute($sql);
	return mysqli_fetch_array($res);
//	return $sql;
	
}
function get_cons_awb($awb)
{
$get_cons= "SELECT * from consignments where cons_id=(SELECT cons_id from tracking where awb='".$awb."')";
$arr= execute($get_cons);
return mysqli_fetch_array($arr);


}
function get_cons_detail($consid)
{
	
	$fetch_cons ="SELECT * from consignments where cons_id=".$consid;
									$fetch_cons_res =execute($fetch_cons);
									return json_encode(mysqli_fetch_array($fetch_cons_res));
	
}


function get_tracking_status($awb,$user_id)
{
$sql="SELECT * from tracking where awb='".$awb."' and user_id=".$user_id;
$res=execute($sql);
if(mysqli_num_rows($res)>0)
return $res;
else
return "Error";


}


//event handle
if(isset($_POST['cons_method']))
{
	if($_POST['cons_method']=="view")
	{
		try{
		echo get_cons_detail($_POST['cons_id']);
		}
			catch (Exception $e)
			{
				echo "402";
			}			
		
	}
if($_POST['cons_method']=="save")
{

//echo $save_qry;


try

{
session_start();
$save_qry ="INSERT INTO consignments (user_id,content,units,weight_kg,perishable,fragile,sender,receiver,from_address,from_country,from_state,from_city,from_zip,to_address,to_country,to_state,to_city,to_zip,created_at)VALUES (".$_SESSION['user_id'].",'".$_POST['content']."','".$_POST['units']."','".$_POST['weight']."','".$_POST['perishable']."','".$_POST['fragile']."','".$_POST['sender']."','".$_POST['receiver']."','".$_POST['from_address']."','".$_POST['from_country']."','".$_POST['from_state']."','".$_POST['from_city']."','".$_POST['from_zip']."','".$_POST['to_address']."','".$_POST['to_country']."','".$_POST['to_state']."','".$_POST['to_city']."','".$_POST['to_zip']."',NOW())";
execute($save_qry);
$cons_id = mysqli_insert_id($GLOBALS['connect']);

$save_payment ="INSERT INTO payments (user_id,cons_id,charges) values(".$_SESSION['user_id'].",".$cons_id.",".$_POST['charges'].")";
execute($save_payment);
//echo $save_payment;
$awb="SEA00".$_SESSION['user_id']."00".$cons_id;
$from_loc=$_POST['from_city']."-".$_POST['from_state']."-".$_POST['from_country'];
$save_track = "INSERT INTO tracking(awb,user_id,last_loc,next_loc,cons_id,status) values ('".$awb."','".$_SESSION['user_id']."','".$from_loc."','Nearest Warehouse',".$cons_id.",'IN-TRANSIT')";

execute($save_track);
//echo $save_track;
echo "200";
}
catch (Exception $e)
{
echo $e;
echo "401";

}
}

else if($_POST['cons_method']=="calc")
{
echo get_cons_charge($_POST['weight']);

}

else if($_POST['cons_method']=="track")
{
session_start();
$track = get_tracking_status($_POST['awb'],$_SESSION['user_id']);
if($track == "Error")
{
echo "<tr><td><span class='btn-warning'>ERROR</span></td><td>";

}
else
{

while($detail=mysqli_fetch_array($track))
{

echo "<tr><td>".$detail['awb']."</td><td>";
echo $detail['last_loc']."</td><td>";
echo $detail['next_loc']."</td><td>";
echo $detail['status']."</td></tr>";



}


//echo "<tr><td>".$track."</td><td>";
}

}

}
if(isset($_POST['profile'])) 
{

if($_POST['profile']=="update")
{
	session_start();
$sql= "UPDATE members SET email='".$_POST["email"]."',fname='".$_POST['firstname']."',lname='".$_POST['lname']."',company='".$_POST['cname']."',website='".$_POST['website']."',contact='".$_POST['contact']."',address='".$_POST['address']."',country='".$_POST['country']."',state='".$_POST['state']."',city='".$_POST['city']."',zip='".$_POST['zip']."' where user_id=".$_SESSION['user_id'];

//execute($sql,$con);

mysqli_query($con,$sql);

echo "200";
mysqli_close($con);
}
}

?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>Invoice</title>

<?php
$group_id=2;
include '../auth.php';
include 'controller.php';
?>
	
   <meta charset="utf-8" />
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <meta content="" name="description" />
   <meta content="" name="author" />
   
   <script src="../configurations/js/jquery-1.8.3.min.js"></script>
   
   <!-- Load Roboto font -->
        <link href="http://fonts.googleapis.com/css?family=Roboto:400,300,700&amp;subset=latin,latin-ext" rel='stylesheet' type='text/css'>
   
   <link href="../configurations/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="../configurations/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="../configurations/assets/bootstrap/css/bootstrap-fileupload.css" rel="stylesheet" />
   <link href="../configurations/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   
   <link href="../configurations/css/style.css" rel="stylesheet" />
   <link href="../configurations/css/style_responsive.css" rel="stylesheet" />
   <link href="../configurations/css/style_default.css" rel="stylesheet" id="style_color" />

   <link href="../configurations/assets/fancybox/source/jquery.fancybox.css" rel="stylesheet" />
   <link rel="stylesheet" type="text/css" href="../configurations/assets/uniform/css/uniform.default.css" />
   
   <!-- Fav and touch icons -->
		<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">
		<link rel="icon" href="../images/favicon.ico" type="image/x-icon"></link>  
   
   
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="fixed-top">
   <!-- BEGIN HEADER -->
   <div id="header" class="navbar navbar-inverse navbar-fixed-top hidden-print">
       <!-- BEGIN TOP NAVIGATION BAR -->
       <div class="navbar-inner">
           <div class="container-fluid">
               <!-- BEGIN LOGO -->
               <a class="brand" href="../home.php">
                   <img src="../configurations/img/logo.png" alt="SeaThunder Logistics" />
               </a>
               <!-- END LOGO -->
               <!-- BEGIN RESPONSIVE MENU TOGGLER -->
               <a class="btn btn-navbar collapsed" id="main_menu_trigger" data-toggle="collapse" data-target=".nav-collapse">
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="arrow"></span>
               </a>
               <!-- END RESPONSIVE MENU TOGGLER -->
               <div id="top_menu" class="nav notify-row">
                   <!-- BEGIN NOTIFICATION -->
                   <ul class="nav top-menu ">
				   
					 <!-- BEGIN my home >
                        <li class="dropdown">
                            <a class="dropdown-toggle element" data-placement="bottom" data-toggle="tooltip" href="home.php" data-original-title="Settings">
                                <i class="icon-home"></i>
                            </a>
                        </li>
                        <!-- END my home -->
				   
					   <?php
					   
					   //include 'inbox.php';
					   //include 'notification.php';
					   
					   ?>
				   </ul>
               </div>
               <!-- END  NOTIFICATION -->
			   
			   
               <div class="top-nav ">
                   <ul class="nav pull-right top-menu" >
                       <!-- BEGIN USER LOGIN DROPDOWN -->
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="font-size:14px;">
                               <img src="../configurations/img/profile-small.png" alt="../configurations/img/profile-small.png">
                               <span class="username"><?php echo $_SESSION['user_name']; ?></span>
                               <b class="caret"></b>
                           </a>
                           <ul class="dropdown-menu">
							   <li><a href="home.php"><i class="icon-home"></i> My Home</a></li>
							   <li><a href="consignment.php"><i class="icon-shopping-cart"></i> My Consignments</a></li>
                               <li><a href="account.php"><i class="icon-cogs"></i> My Account</a></li>
                               <li class="divider"></li>
                               <li><a href="../logout.php"><i class="icon-signout"></i> LOGOUT</a></li>
                           </ul>
                       </li>
                       <!-- END USER LOGIN DROPDOWN -->
                   </ul>
                   <!-- END TOP NAVIGATION MENU -->
				   
               </div>
           </div>
       </div>
       <!-- END TOP NAVIGATION BAR -->
   </div>
   <!-- END HEADER -->
   
   
   <!-- BEGIN CONTAINER -->
   <div id="container" class="row-fluid ">
      <!-- BEGIN SIDEBAR -->
      <div id="sidebar" class="nav-collapse collapse hidden-print">

         <div class="sidebar-toggler hidden-phone"></div>   

         <!-- BEGIN RESPONSIVE QUICK SEARCH FORM >
         <div class="navbar-inverse">
            <form class="navbar-search visible-phone">
               <input type="text" class="search-query" placeholder="Search" />
            </form>
         </div>
         <!-- END RESPONSIVE QUICK SEARCH FORM -->
		 
		 
         <!-- BEGIN SIDEBAR MENU -->
          <ul class="sidebar-menu">
		  
			  <li class="has-sub">
                  <a href="javascript:;" class="" style="padding: 0px; margin:0px;">
                      <span class="icon-box"> <i class="icon-shopping-cart"></i></span>My Consignments
                      <span class="arrow"></span>
				  </a>
				  <ul class="sub">
                      <li><a class="" href="add-consignment.php" style="padding-left: 20px;"><span class="icon-box" style="padding: 10px;"><i class="icon-plus"></i></span>ADD NEW</a></li>
					  <li><a class="" href="view-consignment.php" style="padding-left: 20px;"><span class="icon-box" style="padding: 10px;"><i class="icon-list-alt"></i></span>VIEW ALL</a></li>
                  </ul>
              </li>
			  
			  <li class="has-sub">
                  <a href="track.php" class="">
                      <span class="icon-box"><i class="icon-map-marker"></i></span>Track Consignment
                      <!--span class="arrow"></span-->
                  </a>
              </li>
			  
			  <li class="has-sub">
                  <a href="javascript:;" class="" style="padding: 0px; margin:0px;">
                      <span class="icon-box"> <i class="icon-cogs"></i></span>My Account
                      <span class="arrow"></span>
				  </a>
				  <ul class="sub">
                      <li><a class="" href="profile.php" style="padding-left: 20px;"><span class="icon-box" style="padding: 10px;"><i class="icon-user"></i></span>MY PROFILE</a></li>
					  <li><a class="" href="reset-password.php" style="padding-left: 20px;"><span class="icon-box" style="padding: 10px;"><i class="icon-lock"></i></span>RESET PASSWORD</a></li>
                  </ul>
              </li>
		  		  
              <li class="has-sub">
                  <a href="../logout.php" class="">
                      <span class="icon-box"><i class="icon-signout"></i></span>LOGOUT
                      <!--span class="arrow"></span-->
                  </a>
              </li>
          </ul>
         <!-- END SIDEBAR MENU -->
      </div>
      <!-- END SIDEBAR -->
      
	  
	  
	  
	  
	  
	  <!-- BEGIN PAGE -->  
      <div id="main-content" style="min-height: 400px;">






         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid hidden-print">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     My Consignment Invoice
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
                       <li>
                           <a href="consignment.php">My Consignments</a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="view-consignment.php">View All</a><span class="divider">&nbsp;</span>
                       </li>
                       <li><a href="invoice.php">Invoice</a><span class="divider-last">&nbsp;</span></li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->
			
			
			
			
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
                  <div class="widget">
                        <div class="widget-title hidden-print">
                           <h4><i class="icon-file"></i>Invoice</h4>
                           <span class="tools">
                           <a href="javascript:;" class="icon-chevron-down"></a>
                           <a href="javascript:;" class="icon-remove"></a>
                           </span>                    
                        </div>
                        <div class="widget-body">
                            <div class="row-fluid">
                                <div class="span12 pull-center">
                                    
									<img src="../configurations/img/logo.png" alt="SeaThunder Logistics" style="width:400px; height:80px"/>
									
                                </div>
                            </div>
							
							<div class="space20"></div>
							
							<div class="contact-us">
								<h3>INVOICE</h3>
							</div>
							<?php 
							if(isset($_GET['invcid']))
							{
								$invc=get_cons_detail($_GET['invcid']);
										//print_r($invc);
										$obj=json_decode($invc);
									//print $obj->{'content'};
								}
								?>
                            <div class="row-fluid invoice-list">
								<div class="span4">
								<h5 style="color:#c91010;">SENDER ADDRESS</h5>
									<p>
                                        <?php print $obj->{'sender'}; ?> <br>
                                        <?php print $obj->{'from_address'}; ?> <br>
                                        <?php print $obj->{'from_city'}; ?>,<?php print $obj->{'from_state'}; ?>,<?php print $obj->{'from_country'}; ?><br>
                                        Zipcode: <?php print $obj->{'from_zip'}; ?>
                                    </p>
								</div>	
								<div class="span4">
									<h5 style="color:#c91010;">RECEIVER ADDRESS</h5>
									<p><?php print $obj->{'receiver'}; ?> <br>
                                        <?php print $obj->{'to_address'}; ?> <br>
                                        <?php print $obj->{'to_city'}; ?>,<?php print $obj->{'to_state'}; ?>,<?php print $obj->{'to_country'}; ?><br>
                                        Zipcode: <?php print $obj->{'to_zip'}; ?>
                                    </p>
								</div>	
								<?php $payment=get_payment_detail($obj->{'cons_id'},$_SESSION['user_id']);
//								echo $payment;
								?>
								<div class="span4">
									<h5 style="color:#c91010;">INVOICE INFO</h5>
									<p>
                                        Consignment ID	: <strong>SEA00<?php echo $_SESSION['user_id'];?>00<?php print $obj->{'cons_id'}; ?></strong></br>
                                        Date			: <?php print $obj->{'created_at'}; ?></br>
                                        Status			: <?php if($payment['is_paid']==0)echo "Unpaid";else echo "Paid"; ?></br>
                                    </p>
								</div>
                            </div>
                            <div class="space20"></div>
                            <div class="space20"></div>
                            <div class="row-fluid">
                                <table class="table table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Content Description</th>
										<th>Total Parcel Units</th>
										<th>Total Weight</th>
                                        <th>Cost/Kg</th>
                                        <th>Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td><?php print $obj->{'content'}; ?></td>
										<td><?php print $obj->{'units'}; ?></td>
                                        <td><?php print $obj->{'weight_kg'}; ?></td>
                                        <td>Rs. 25</td>
                                        <td><?php print $payment['charges']; ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
							
                            <div class="space20"></div>
                            <div class="row-fluid">
                                <div class="span4 invoice-block pull-right">
                                    <ul class="amounts">
                                        <li><strong>Sub - Total amount :</strong> Rs. <?php print $payment['charges']; ?><br>(inclusive of all taxes)</li>
                                        <!--li><strong>Discount :</strong> 10%</li-->
										<li><strong>Shipping Rate :</strong> Rs. 50</li>
                                        <li><strong>Tariff Rate :</strong> 10%</li>
                                        <li><strong>Grand Total :</strong> Rs. <?php print $payment['charges']+50; ?></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="space20"></div>
                            <div class="row-fluid text-center">
								<a onclick="javascript:window.print();" class="btn btn-info hidden-print">Print <i class="icon-print"></i></a>
                                <a class="hide btn btn-inverse hidden-print">Close<i class="m-icon-swapright m-icon-white"></i></a>
                            </div>
                        </div>
                  </div>
               </div>
            </div>
            <!-- END PAGE CONTENT-->         
         </div>
         <!-- END PAGE CONTAINER-->
      </div>
      <!-- END PAGE -->  
   </div>
   <!-- END CONTAINER -->

   

   
   
   
<!-- Footer section start -->
        <div id="footer" class=" hidden-print" >
			<div class="row-fluid">
			<a href="../home.php"><img src="../images/logo_bw.png"  alt="SeaThunder Logistics" align="left" style="width:510px; height:90px; vertical-align:middle;"></a>
			</div>
			<br>
			<div class="row-fluid">
				<div class="span2"></div>
				<div class="span3">
					<ul>
						<li><a href="../home.php" style="font-size:16px;">Home</a></li>
						<li><a href="../services.php" style="font-size:16px;">Services</a></li>
						<li><a href="../fleet.php" style="font-size:16px;">Fleet</a></li>
						<li><a href="../clients.php" style="font-size:16px;">Clients</a></li>
						<li><a href="../feedback.php" style="font-size:16px;">Feedback</a></li>
						<li><a href="../track.php" style="font-size:16px;">Track</a></li>
						<li><a href="../login.php" style="font-size:16px;">Login</a></li>
						<li><a href="../signup.php" style="font-size:16px;">Signup</a></li>
					</ul>
				</div>
				<div class="span3">
					<ul>
						<li><a href="home.php" style="font-size:16px;">My Home</a></li>
						<li><a href="consignment.php" style="font-size:16px;">My Consignments</a></li>
						<li><a href="track.php" style="font-size:16px;">Track My Consignment</a></li>
						<li><a href="account.php" style="font-size:16px;">My Account</a></li>
						<li><a href="../logout.php" style="font-size:16px;">Logout</a></li>
					</ul>
				</div>
				<div class="span3">
					<ul>
						<li style="font-size:16px;">SEBIZ SQUARE</li>
						<li style="font-size:16px;">Plot No. IT-C6,	I.T.Park, Sector-67,</li>
						<li style="font-size:16px;">Sahibzada Ajit Singh Nagar,</li>
						<li style="font-size:16px;">Punjab 160062</li>
						<li style="font-size:16px;">mailus@seathunder.com</li>
						<li style="font-size:16px;">+91-172-306-8070</li>
					</ul>
				</div>
				<div class="span1">
				</div>
			</div>
			<div class="row-fluid" style="margin-left:20px; padding-top:1%;">	
				<span style="color:#B8B8B8;">2015 &copy; <a href="../home.php">SeaThunder Logistics.</a> All Rights Reserved.</span>
			</div>
			
        </div>
        <!-- Footer section end -->
   
   
				<!-- ScrollUp button start -->
				<div class="scrollup hidden-print">
					<a href="#">
						<i class="icon-chevron-up"></i>
					</a>
				</div>
				<!-- ScrollUp button end -->
   
   
   <!-- BEGIN JAVASCRIPTS -->    
   <!-- Load javascripts at bottom, this will reduce page load time >
   <script src="../configurations/js/jquery-1.8.3.min.js"></script-->
   <script src="../configurations/assets/bootstrap/js/bootstrap.min.js"></script>
   <script src="../configurations/js/jquery.blockui.js"></script>
   <!-- ie8 fixes -->
   <!--[if lt IE 9]>
   <script src="../configurations/js/excanvas.js"></script>
   <script src="../configurations/js/respond.js"></script>
   <![endif]-->
   
   <script type= "text/javascript" src ="countries3.js"></script>
   
   <script type="text/javascript" src="../configurations/assets/chosen-bootstrap/chosen/chosen.jquery.min.js"></script>
   <script type="text/javascript" src="../configurations/assets/uniform/jquery.uniform.min.js"></script>
   <script type="text/javascript" src="../configurations/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="../configurations/assets/data-tables/DT_bootstrap.js"></script>
   
   <script src="../configurations/assets/jqvmap/jqvmap/jquery.vmap.js" type="text/javascript"></script>
	<script src="../configurations/assets/fancybox/source/jquery.fancybox.pack.js"></script>
	
	
	<script src="../configurations/js/scripts.js"></script>
	
	
   
   <script>
      jQuery(document).ready(function() {       
         // initiate layout and plugins
         App.init();
		print_country("from_country");
		print_country("to_country");
		//jQuery("#tracktable").hide();
		
		
		//scroll to top
		
			//Check to see if the window is top if not then display button
			jQuery(window).scroll(function(){
				if (jQuery(this).scrollTop() > 40) {
					jQuery('.scrollup').fadeIn();
				} else {
					jQuery('.scrollup').fadeOut();
				}
			});
	
			/*Click event to scroll to top
			jQuery('.scrollup').click(function(){
				jQuery('html, body').animate({scrollTop : 0},800);
				return false;
			});*/
		//scroll to top end

		
      });
   </script>
   <!-- END JAVASCRIPTS -->   
</body>
<!-- END BODY -->
</html>
   

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>My Profile</title>
   

<?php
$group_id=2;
include 'header.php';
?>


         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     My Profile
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="account.php">My Account</a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="profile.php">My Profile</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->


 <!-- BEGIN PAGE CONTENT: PROFILE-->
            <div class="row-fluid">
				<div class="span12">
					<div class="widget">
                        <div class="widget-title">
                           <h4><i class="icon-user"></i> Profile</h4>
                           <span class="tools">
                           <a href="javascript:;" class="icon-chevron-down"></a>
                           <a href="javascript:;" class="icon-remove"></a>
                           </span>                    
                        </div>
                        <div class="widget-body">
						<?php $fetch_profile ="SELECT * from members where user_id=".$_SESSION['user_id'];
									$fetch_profile_res =execute($fetch_profile);
										while($profile_detail = mysqli_fetch_array($fetch_profile_res,MYSQLI_ASSOC))
										{
																				
										?>
									
                            <div class="span3">
                                <div class="text-center profile-pic">
                                    <img src="images/profiles/<?php echo $profile_detail['logo']; ?>" alt="Profile Image">
                                </div>
                                <ul class="nav nav-tabs nav-stacked">
                                    <li style="color:#006699;"><center>Company Logo</center></li>
                                </ul>
                            </div>
							
							<div class="span1"></div>
							
                            <div class="span6">
                                <h4>COMPANY PROFILE<br/><small></small></h4>
                                <table class="table table-borderless">
                                    <tbody>
									
                                    <tr>
                                        <td class="span3">Full Name :</td>
                                        <td>
                                            <?php echo $profile_detail['fname']." ".$profile_detail['lname']; ?>
                                        </td>
										
                                    </tr>
									<tr>
                                        <td class="span3">Email :</td>
                                        <td>
                                            <?php echo $profile_detail['email']; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="span3">Company Name :</td>
                                        <td>
                                            <?php echo $profile_detail['company']; ?>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span3">Website :</td>
                                        <td>
                                            <?php echo $profile_detail['website']; ?>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span3">Contact No. :</td>
                                        <td>
                                            <?php echo $profile_detail['contact']; ?>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span3">Address :</td>
                                        <td>
                                            <?php echo $profile_detail['address']; ?>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span3">City :</td>
                                        <td>
                                            <?php echo $profile_detail['city']; ?>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span3">Zipcode :</td>
                                        <td>
                                            <?php echo $profile_detail['zip']; ?>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span3">State :</td>
                                        <td>
                                            <?php echo $profile_detail['state']; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="span3">Country :</td>
                                        <td>
                                            <?php echo $profile_detail['country']; ?>
                                        </td>
                                    </tr>
									<?php } ?>
                                    </tbody>
                                </table>
								<br>
								
								<ul class="nav nav-tabs nav-stacked">
									
									<li><center><a href="edit-profile.php" class="btn btn-info span4" style="border:2px solid #069;"><i class="icon-pencil"></i> Edit Profile</a></center></li>
									
                                </ul>
								
                            </div>
							
                            <div class="span3">
                                
                            </div>
							
                            <div class="space5"></div>
                        </div>
					</div>
				</div>
            </div>
            <!-- END PAGE CONTENT: PROFILE-->         
			</div>
         <!-- END PAGE CONTAINER-->
      </div>
      <!-- END PAGE -->  
   </div>
   <!-- END CONTAINER -->
			

<?php

include 'footer.php';
//include 'profile-footer.php';

?>
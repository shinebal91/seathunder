<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>Feedback</title>

<?php
$group_id=2;
include 'header.php';
?>


         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     Feedback
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   
					   <li>
                           <a href="feedback.php">Feedback</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->



			<!-- BEGIN PAGE CONTENT-->
				<div id="page">
					<div class="row-fluid">
						<div class="span12">
							<!-- BEGIN BASIC PORTLET-->
							<div class="widget">
								<div class="widget-title">
									<h4><i class="icon-list-alt"></i> Send Us Your Feedback</h4>
									<span class="tools">
									<a href="javascript:;" class="icon-chevron-down"></a>
									<a href="javascript:;" class="icon-remove"></a>
									</span>
								</div>
								<div class="widget-body">
									
                                    <!--BEGIN CONTACT US-->
                                    <div class="contact-us">
                                        
                                        <div class="space20"></div>
                                        <div class="row-fluid">
                                            <div class="feedback">
                                                <h3>FEEDBACK</h3>
                                                <h4 style="color:#c91010;"><center>Have a Comment or a Complaint ??</center></h4>
                                                <div class="space20"></div>

                                                <form class="form-inline" id="user-fb" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
												
													<div class="span4 hide"></div>
                                                    <div class="control-group hide">
                                                        <input type="text" class="span4" placeholder="Company Name">
													</div>
													
													<div class="span3"></div>
                                                    <div class="control-group">
                                                        <input type="text" class="span6" placeholder="Company Name" name="name" id="name" required>
													</div>
													
													<div class="span3"></div>
                                                    <div class="control-group">
                                                        <input type="email" class="span6" placeholder="Email" name="email" id="email" required>
													</div>
													
													<div class="span3"></div>
                                                    <div class="control-group">
                                                        <textarea rows="6" class="span6" placeholder="Message" name="comments" id="comments" required></textarea>
                                                    </div>
                                                    <div class="text-center">
                                                    <button type="submit" class="btn btn-info" name="send-feedback" id="send-feedback">Submit</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!--END CONTACT US-->
								</div>
							</div>
							<!-- END BASIC PORTLET-->
						</div>

					</div>

				</div>
				<!-- END PAGE CONTENT-->
			</div>
			<!-- END PAGE CONTAINER--> 			
		</div>
		<!-- END PAGE -->
	</div>
	<!-- END CONTAINER -->
	
	
	
<?php

include "footer.php";


if(isset($_POST['send-feedback']))
	{     include('config.php'); 
		//include 'site-controller.php';
		$sql= 'Insert into feedback (name,email,comments) VALUES ("'.$_POST['name'].'","'.$_POST['email'].'","'.$_POST['comments'].'")';
		//echo $sql;
		try
		{
			mysqli_query($con,$sql);
			echo "<script> alert('Thanks For Your Valuable Feedback... Good Day..!!');</script>";
		}
		catch(Exception $e)
		{
			echo 'Message: ' .$e->getMessage();
			echo "<script> alert('SOME ERROR OCCURED. PLEASE CONTACT ADMIN');</script>";
		}
	}





?>
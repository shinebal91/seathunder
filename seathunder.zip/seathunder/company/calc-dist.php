<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>Google Maps JavaScript API Example: Extraction of Geocoding Data</title>
    <script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAA7j_Q-rshuWkc8HyFI4V2HxQYPm-xtd00hTQOC0OXpAMO40FHAxT29dNBGfxqMPq5zwdeiDSHEPL89A" type="text/javascript"></script>
<!-- According to the Google Maps API Terms of Service you are required display a Google map when using the Google Maps API. see: http://code.google.com/apis/maps/terms.html -->
    <script type="text/javascript">

    var geocoder, location1, location2;

    function initialize() {
        geocoder = new GClientGeocoder();
    }

    function showLocation() {
        geocoder.getLocations(document.forms[0].address1.value, function (response) {
            if (!response || response.Status.code != 200)
            {
                alert("Sorry, we were unable to geocode the first address");
            }
            else
            {
                location1 = {lat: response.Placemark[0].Point.coordinates[1], lon: response.Placemark[0].Point.coordinates[0], address: response.Placemark[0].address};
                geocoder.getLocations(document.forms[0].address2.value, function (response) {
                    if (!response || response.Status.code != 200)
                    {
                        alert("Sorry, we were unable to geocode the second address");
                    }
                    else
                    {
                        location2 = {lat: response.Placemark[0].Point.coordinates[1], lon: response.Placemark[0].Point.coordinates[0], address: response.Placemark[0].address};
                        calculateDistance();
                    }
                });
            }
        });
    }
    
    function calculateDistance()
    {
        try
        {
            var glatlng1 = new GLatLng(location1.lat, location1.lon);
            var glatlng2 = new GLatLng(location2.lat, location2.lon);
            var miledistance = glatlng1.distanceFrom(glatlng2, 3959).toFixed(1);
            var kmdistance = (miledistance * 1.609344).toFixed(1);
if (miledistance<=500 || kmdistance<=805)
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=1 day';
		}
		else if ((miledistance>500 && miledistance<=1000) || (kmdistance>805 && kmdistance<=1610))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=2 days';
		}
		else if ((miledistance>1000 && miledistance<=1500) || (kmdistance>1610 && kmdistance<=2415))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=3 days';
		}
		else if ((miledistance>1500 && miledistance<=2000) || (kmdistance>2415 && kmdistance<=3220))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=4 days';
		}
		else if ((miledistance>2000 && miledistance<=2500) || (kmdistance>3220 && kmdistance<=4025))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=5 days';
		}
		else if ((miledistance>2500 && miledistance<=3000) || (kmdistance>4025 && kmdistance<=4828))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=6 days';
		}
		else if ((miledistance>3000 && miledistance<=3500) || (kmdistance>4828 && kmdistance<=5632))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=1 week';
		}
		else if ((miledistance>3500 && miledistance<=4000) || (kmdistance>5632 && kmdistance<=6438))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=8 days';
		}
		else if ((miledistance>4000 && miledistance<=4500) || (kmdistance>6438 && kmdistance<=7242))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=9 days';
		}
		else if ((miledistance>4500 && miledistance<=5000) || (kmdistance>7242 && kmdistance<=8047))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=10 days';
		}
		else if ((miledistance>5000 && miledistance<=5500) || (kmdistance>8047 && kmdistance<=8852))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=11 days';
		}
		else if ((miledistance>5500 && miledistance<=6000) || (kmdistance>8852 && kmdistance<=9657))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=12 days';
		}
		else if ((miledistance>6000 && miledistance<=6500) || (kmdistance>9657 && kmdistance<=10461))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=13 days';
		}
		else if ((miledistance>6500 && miledistance<=7000) || (kmdistance>10461 && kmdistance<=11266))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=2 weeks';
		}
		else if ((miledistance>7000 && miledistance<=7500) || (kmdistance>11266 && kmdistance<=12071))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=15 days';
		}
		else if ((miledistance>7500 && miledistance<=8000) || (kmdistance>12071 && kmdistance<=12875))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=16 days';
		}
		else if ((miledistance>8000 && miledistance<=8500) || (kmdistance>12875 && kmdistance<=13680))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=17 days';
		}
		else if ((miledistance>8500 && miledistance<=9000) || (kmdistance>13680 && kmdistance<=14485))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=18 days';
		}
		else if ((miledistance>9000 && miledistance<=9500) || (kmdistance>14485 && kmdistance<=15289))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=19 days';
		}
		else if ((miledistance>9500 && miledistance<=10000) || (kmdistance>15289 && kmdistance<=16094))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=20 days';
		}
		else if ((miledistance>10000 && miledistance<=10500) || (kmdistance>16094 && kmdistance<=16899))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=3 weeks';}
		else if ((miledistance>10500 && miledistance<=11000) || (kmdistance>16899 && kmdistance<=17705))
		{
            document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)<br /><strong>Time: </strong>=22 days';
		}
		else{document.getElementById('results').innerHTML='wrong input';}
		}
        catch (error)
        {
            alert(error);
        }
    }

    </script>
  </head>

  <body onload="initialize()">

    <form action="#" onsubmit="showLocation(); return false;">
      <p>
        <input type="text" name="address1" value="Address 1" class="address_input" size="40" />
        <input type="text" name="address2" value="Address 2" class="address_input" size="40" />
        <input type="submit" name="find" value="search" />
      </p>
    </form>
    <p id="results"></p>

  </body>
</html>
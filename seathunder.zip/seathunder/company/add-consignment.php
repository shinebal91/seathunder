<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>Add New Consignment</title>

<?php
$group_id=2;
include 'header.php';
?>


         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     Add New Consignment
                     <small></small>
                  </h3>
                   <ul class="breadcrumb" >
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="consignment.php">My Consignments</a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="add-consignment.php">Add New</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->
   <div style="display: none; width:65%;left:37%" id="myModal3" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true" >
			

                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h3 id="myModalLabel3><i class="icon-briefcase"></i>&nbsp;Consignment Charges</h3>
                                        </div>
                               <div class="modal-body">
							  
							   <div class="span12">
							   <table class="table table-striped table-borderless">
							   <tbody>
							   <tr>
									<td class="span4" style="border-top:0px;"><h4>Total Parcel Units</h4></td>
									<td style="border-top:0px;"><h4> : </h4></td>
									<td style="border-top:0px;"><h4><span id="resp-units"></span></h4></td>
							   </tr>
							   <tr>
									<td class="span4"><h4>Total Weight(Kgs.)</h4></td>
									<td><h4> : </h4></td>
									<td><h4><span id="resp-weight"></span></h4></td>
							   </tr>
							   <tr>
									<td class="span4"><h4>Cost/Kg</h4></td>
									<td><h4> : </h4></td>
									<td><h4>Rs. 25</h4></td>
							   </tr>
							   <tr>
									<td class="span4"><h4>Tariff</h4></td>
									<td><h4> : </h4></td>
									<td><h4>10%</h4></td>
							   </tr>
							   <tr>
									<td class="span4"><h4>Total Charges</h4></td>
									<td><h4> : </h4></td>
									<td><h4>Rs. <span id="resp-charge"></span></h4></td>
							   </tr>
							   </tbody>
							   </table>
							   
								</div>
								
																
							   </div>
							    <div class="modal-footer">
								<button class="btn btn-info" id="proceed" onclick="senddata();"><i class="icon-shopping-cart" ></i> Proceed</button>
								<button class="btn btn-warning" data-dismiss="modal" aria-hidden="true"><i class="icon-pencil" ></i> Edit</button>
							 	<div class="span8" id="response-save"></div>
								
								</div>
	</div>

 <!-- BEGIN PAGE CONTENT: PROFILE-->
            <div class="row-fluid">
				<div class="span12">
					<div class="widget">
                        <div class="widget-title">
                           <h4><i class="icon-shopping-cart"></i> Add Consignment</h4>
                           <span class="tools">
                           <a href="javascript:;" class="icon-chevron-down"></a>
                           <a href="javascript:;" class="icon-remove"></a>
                           </span>                    
                        </div>
						
						<!--hidden-phone-->
                        <div class="widget-body">
								<div class="span1"></div>
							<div class="span10">
                                <h4>CONSIGNMENT DETAILS<br/><small></small></h4>
                          
						  <table class="table table-borderless">

						  <tbody>
                                    <tr>
                                        <td class="span2">Content :</td>
                                        <td colspan=3>
                                            <textarea style="width:647px" name="content" id="content" rows="3" required></textarea>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2"> Total Parcel Units :</td>
                                        <td>
                                            <input type="number" name="units" id="units" min="0" required>
                                        </td>
										<td class="span2">Weight (in Kgs.):</td>
                                        <td>
                                            <input type="number" name="weight" id="weight" min="0" required>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2">Contains perishable item?</td>
                                        <td><input class="radio" type="radio" name="perishable" id="perishable" value="yes">YES
										<input class="radio" type="radio" name="perishable" id="perishable" value="no">NO
                                        </td>
										<td class="span2">Contains fragile item?</td>
                                        <td><input class="radio-inline" type="radio" name="fragile" id="fragile" value="yes">YES
										<input class="radio-inline" type="radio" name="fragile" id="fragile" value="no">NO
											
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2"></td>
                                        <td style="color:#c91010;">
                                            SENDER'S ADDRESS
                                        </td>
										<td class="span2"></td>
                                        <td style="color:#c91010;">
                                            RECEIVER'S ADDRESS
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2">Sender :</td>
                                        <td>
                                            <input type="text" name="sender" id="sender" placeholder="Company Name" required>
                                        </td>
										<td class="span2">Receiver :</td>
                                        <td>
                                            <input type="text" name="receiver" id="receiver" placeholder="Company Name" required>
                                        </td>
                                    </tr>
									<tr>
										<td class="span2">Address :</td>
                                        <td>
                                            <textarea name="from_address" id="from_address" rows="3" placeholder="Sender's Address" required></textarea>
                                        </td>
										
										<td class="span2">Address :</td>
                                        <td>
                                            <textarea name="to_address" id="to_address" rows="3" placeholder="Receiver's Address" required></textarea>
                                        </td>
									</tr>
									<tr>
										<td class="span2">Country :</td>
										<td><select name="from_country" id="from_country" onchange="print_state('from_state', this.selectedIndex);" required><option value>SELECT COUNTRY<option>
										</select></td>
										
										<td class="span2">Country :</td>
										<td><select name="to_country" id="to_country" onchange="print_state('to_state', this.selectedIndex);" required><option value>SELECT COUNTRY<option>
										</select></td>
									</tr>
									<tr>
										<td class="span2">State :</td>
										<td><select name ="from_state" id ="from_state" required><option value>SELECT STATE<option></select></td>
                                        
										<td class="span2">State :</td>
										<td><select name ="to_state" id ="to_state" required><option value>SELECT STATE<option></select></td>
									</tr>
									<tr>
                                        <td class="span2">City :</td>
                                        <td>
                                            <input type="text" name="from_city" id="from_city" required>
                                        </td>
										<td class="span2">City :</td>
                                        <td>
                                            <input type="text" name="to_city" id="to_city" required>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2">Zipcode :</td>
                                        <td>
                                            <input type="number" name="from_zip" id="from_zip" min="0" required>
                                        </td>
										<td class="span2">Zipcode :</td>
                                        <td>
                                            <input type="number" name="to_zip" id="to_zip" min="0" required>
                                        </td>
                                    </tr>
            
			</tbody>
                                </table>
								
								<ul class="nav nav-tabs nav-stacked">
									<li><h4></h4>
                                <center><button  class="btn btn-info" id="proceed" onclick="calc();"><i class="icon-shopping-cart"></i> Proceed to Payment</button>
								
								</center></li>
                                </ul>
								
                                </div>
								<div class="span1"></div>
                            </div><!--hidden phone-->
							

							<!--VISIBLE PHONE>
							
							<div class="widget-body">
								<div class="span1"></div>
							<div class="span10">
                                <h4>CONSIGNMENT DETAILS<br/><small></small></h4>
                          
						  <table class="table table-borderless">

						  <tbody>
                                    <tr>
                                        <td class="span2">Content :</td>
                                        <td colspan=3>
                                            <textarea style="width:647px" name="content" id="content" rows="3" required></textarea>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2"> Total Parcel Units :</td>
                                        <td>
                                            <input type="number" name="units" id="units" min="0" required>
                                        </td>
										<td class="span2">Weight (in Kgs.):</td>
                                        <td>
                                            <input type="number" name="weight" id="weight" min="0" required>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2">Contains perishable item?</td>
                                        <td><input class="radio" type="radio" name="perishable" id="perishable" value="yes">YES
										<input class="radio" type="radio" name="perishable" id="perishable" value="no">NO
                                        </td>
										<td class="span2">Contains fragile item?</td>
                                        <td><input class="radio-inline" type="radio" name="fragile" id="fragile" value="yes">YES
										<input class="radio-inline" type="radio" name="fragile" id="fragile" value="no">NO
											
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2"></td>
                                        <td style="color:#c91010;">
                                            SENDER'S ADDRESS
                                        </td>
										<td class="span2"></td>
                                        <td style="color:#c91010;">
                                            RECEIVER'S ADDRESS
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2">Sender :</td>
                                        <td>
                                            <input type="text" name="sender" id="sender" placeholder="Company Name" required>
                                        </td>
										<td class="span2">Receiver :</td>
                                        <td>
                                            <input type="text" name="receiver" id="receiver" placeholder="Company Name" required>
                                        </td>
                                    </tr>
									<tr>
										<td class="span2">Address :</td>
                                        <td>
                                            <textarea name="from_address" id="from_address" rows="3" placeholder="Sender's Address" required></textarea>
                                        </td>
										
										<td class="span2">Address :</td>
                                        <td>
                                            <textarea name="to_address" id="to_address" rows="3" placeholder="Receiver's Address" required></textarea>
                                        </td>
									</tr>
									<tr>
										<td class="span2">Country :</td>
										<td><select name="from_country" id="from_country" onchange="print_state('from_state', this.selectedIndex);" required><option value>SELECT COUNTRY<option>
										</select></td>
										
										<td class="span2">Country :</td>
										<td><select name="to_country" id="to_country" onchange="print_state('to_state', this.selectedIndex);" required><option value>SELECT COUNTRY<option>
										</select></td>
									</tr>
									<tr>
										<td class="span2">State :</td>
										<td><select name ="from_state" id ="from_state" required><option value>SELECT STATE<option></select></td>
                                        
										<td class="span2">State :</td>
										<td><select name ="to_state" id ="to_state" required><option value>SELECT STATE<option></select></td>
									</tr>
									<tr>
                                        <td class="span2">City :</td>
                                        <td>
                                            <input type="text" name="from_city" id="from_city" required>
                                        </td>
										<td class="span2">City :</td>
                                        <td>
                                            <input type="text" name="to_city" id="to_city" required>
                                        </td>
                                    </tr>
									<tr>
                                        <td class="span2">Zipcode :</td>
                                        <td>
                                            <input type="number" name="from_zip" id="from_zip" min="0" required>
                                        </td>
										<td class="span2">Zipcode :</td>
                                        <td>
                                            <input type="number" name="to_zip" id="to_zip" min="0" required>
                                        </td>
                                    </tr>
            
			</tbody>
                                </table>
								
								<ul class="nav nav-tabs nav-stacked">
									<li><h4></h4>
                                <center><button  class="btn btn-info" id="proceed" onclick="calc();"><i class="icon-shopping-cart"></i> Proceed to Payment</button>
								
								</center></li>
                                </ul>
								
                                </div>
								<div class="span1"></div>
                            </div><!--visible phone-->
							
							
							
							
							
                            <div class="space5">
							<a href="#myModal3" role="button" style="margin-bottom: 9.5px;" class="btn btn-success hide" data-toggle="modal" id="modal3-trigger"></a>
								</div>
				               
							   </div>
					</div>
			</div><!-- END PAGE CONTENT: profile-->
			
			</div>
         <!-- END PAGE CONTAINER-->
      </div>
      <!-- END PAGE -->  
   </div>
   <!-- END CONTAINER -->

<script>


function senddata()
{
var perishable , fragile ;
if(jQuery('#perishable').is(':checked') == true)
{
perishable=1;
}
else if(jQuery('#perishable').is(':checked') == false)
{
perishable=0;
}
if(jQuery('#fragile').is(':checked') == true)
{
fragile=1;
}
else if(jQuery('#fragile').is(':checked') == false)
{
fragile=0;
}

var datastr="cons_method=save&content=" + jQuery("#content").val() + "&units="+ jQuery("#units").val() + "&weight="+ jQuery("#weight").val() + "&perishable="+ perishable + "&fragile="+ fragile + "&sender="+ jQuery("#sender").val()  + "&receiver="+ jQuery("#receiver").val() +  "&from_address="+ jQuery("#from_address").val() + "&to_address="+ jQuery("#to_address").val() + "&from_country="+ jQuery("#from_country").val() +   "&to_country="+ jQuery("#to_country").val() + "&from_state="+ jQuery("#from_state").val() + "&to_state="+ jQuery("#to_state").val() +   "&from_city="+ jQuery("#from_city").val() + "&to_city="+ jQuery("#to_city").val() + "&from_zip="+ jQuery("#from_zip").val() +   "&to_zip="+ jQuery("#to_zip").val() +"&charges=" + jQuery("#resp-charge").html() ;
	 
jQuery.ajax({
	 type:'POST',
	 data:datastr,
	 url:'controller.php',
	 success: function(data) { 
	 if(data == 200)
	 {
	 jQuery('#proceed').html("Consignment Saved");
	 jQuery(':input').val("");
	 jQuery('#proceed').prop('disabled', true);
	 //jQuery('#modal3-trigger').trigger("click");
	 
	 }
	 else
	 {
	 alert("Some Error Occured. Please Try Again Or Contact Administrator");  
	 
	 }
	 }
	 
	 });

//jQuery('#modal3-trigger').trigger("click");
jQuery('#myModal3').fadeOut(1000, complete);
}

function calc()
{
	if(jQuery('#from_zip').val()=='')
	{
	alert("Please Fill All Fields")	
	}
	else
	{
var datastr="cons_method=calc&weight=" + jQuery("#weight").val() ;
	 jQuery.ajax({
	 type:'POST',
	 data:datastr,
	 url:'controller.php',
	 success: function(data) { jQuery('#resp-charge').html(data);
	 
	 jQuery("#resp-units").text(jQuery('#units').val());
	 jQuery("#resp-weight").text(jQuery('#weight').val());
	 
	 jQuery('#modal3-trigger').trigger("click");
	 }
	 });
	
	}
}

//jQuery("#modalclose").click( function(){ 	 });
</script>
			

<?php

include 'footer.php';

?>

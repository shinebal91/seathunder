<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>Reset Password</title>
   

<?php
$group_id=2;
include 'header.php';
?>


         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     Reset Password
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="account.php">My Account</a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="reset-password.php">Reset Password</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->


 <!-- BEGIN PAGE CONTENT: PROFILE-->
            <div class="row-fluid">
				<div class="span12">
					<div class="widget">
                        <div class="widget-title">
                           <h4><i class="icon-lock"></i> Reset Password</h4>
                           <span class="tools">
                           <a href="javascript:;" class="icon-chevron-down"></a>
                           <a href="javascript:;" class="icon-remove"></a>
                           </span>                    
                        </div>
                        <div class="widget-body">
							<div class="span3">
							</div>
                           							
                            <div class="span6">
                                <h4>Reset Password<br/><small></small></h4>
								<form name="changepass" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <table class="table table-borderless">
                                    <tbody>
                                    <tr>
                                        <td class="span3">Old Password :</td>
                                        <td>
                                            <input type="password" name="oldpass" id="oldpass" required>
                                        </td>
										<td><span><i id="op"></i></span></td>
                                    </tr>
									<tr>
                                        <td class="span3">New Password :</td>
                                        <td>
                                            <input type="password" name="newpass" id="newpass" required>
                                        </td>
										<td><span class="btn-success" style="border:0px;"><i id="np"></i></span></td>
                                    </tr>
                                    <tr>
                                        <td class="span3">Re-Type Password :</td>
                                        <td>
                                            <input type="password" name="cpass" id="cpass" onchange="check(this.value);"required>
                                        </td>
										<td><span class="btn-success" id="cpsp" style="border:0px;"><i id="cp"></i></span></td>
                                    </tr>
								    </tbody>
                                </table>
                                
								<ul class="nav nav-tabs nav-stacked">
									<li id="error" class="btn-danger" style="border:0px;"></li>
									<li><h4></h4><center>
                                <input type="submit" value="Change Password" name="submit" id="save" class="btn btn-info"></center></li>
                                </ul>
								</form>
                            </div>
							
                            
                            <div class="space5"></div>
                        </div>
					</div>
				</div>
            </div>
            <!-- END PAGE CONTENT: PROFILE-->         
			</div>
         <!-- END PAGE CONTAINER-->
      </div>
      <!-- END PAGE -->  
   </div>
   <!-- END CONTAINER -->
			

<?php

include 'footer.php';


//$_SESSION["user_id"] = "3";

if(isset($_POST['submit']))
{

include('../config.php');
$cpass=md5(sha1($_POST['cpass']));

$result = mysqli_query($con,"SELECT * from members WHERE user_id='" . $_SESSION["user_id"] . "'");
$row=mysqli_fetch_array($result);
if(($old=md5(sha1($_POST["oldpass"]))) == ($row["passkey"])) {
mysqli_query($con,"UPDATE members set passkey='" . $cpass . "' WHERE user_id='" . $_SESSION["user_id"] . "'");
echo "<script>alert('Password Changed Successfully You Will Be Logged Out Now');</script>";
session_destroy();
echo "<script>window.location.reload();</script>";

} 
else echo "<script>alert('Some Error Occured');</script>";
}


?>

<script>
function check(cpass)
{
var newpass=jQuery("#newpass").val();
if(cpass != newpass)
{
	jQuery("#error").html("<p class='btn-danger'>Password Do Not Match</p>");
	jQuery("#newpass").focus();
	jQuery('#np').addClass( "icon-ok " );
	jQuery('#cp').addClass( "icon-remove " );
	jQuery('#cpsp').removeClass("btn-success").addClass( "btn-danger " );
	jQuery('#save').prop('disabled', true);

	}
else
	
{	
jQuery('#np').addClass( "icon-ok " );
jQuery('#cp').removeClass("icon-remove").addClass( "icon-ok " );
	jQuery("#error").html("");	
	jQuery('#save').prop('disabled', false);

}

	}

</script>

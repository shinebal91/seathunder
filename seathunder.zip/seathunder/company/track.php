<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>Track Consignment</title>

<?php
$group_id=2;
include 'header.php';
?>


         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     Track Consignment
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   <li>
                           <a href="track.php">Track Consignment</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->


			<div class="row-fluid">
				<div class="span12">
					<div class="widget">
                        <div class="widget-title">
                           <h4><i class="icon-map-marker"></i> Track Consignment Location</h4>
                           <span class="tools">
                           <a href="javascript:;" class="icon-chevron-down"></a>
                           <a href="javascript:;" class="icon-remove"></a>
                           </span>                    
                        </div>
                        <div class="widget-body">
								<div class="span1"></div>
							<div class="span10">
                                <h4>ENTER THE <span style="color:#c91010;">CONSIGNMENT ID</span> TO KNOW WHERE YOUR SHIPMENT IS<br/><small></small></h4>
                                <table class="table table-borderless">
                                    <tbody>
                                    <tr>
                                       <td class="span2" ><input type="text" name="cons_id" id="cons_id" min="0" value="<?php if(isset($_GET['cons_status'])){echo $_GET['cons_status'];}?>"									   placeholder="Consignment ID"></td><td><button id="track" onclick="track();" class="btn btn-info"><i class="icon-map-marker"></i> GO</button></td> 
                                    </tr>
                                    </tbody>
                                </table>
								</div>
                            </div>
							

                            <div class="space5"></div>
                        </div>
						<div class="widget hide" id="tracktable">
                        <div class="widget-title">
                           <h4><i class="icon-map-marker"></i> Consignment Location Details</h4>
                           <span class="tools">
                           <a href="javascript:;" class="icon-chevron-down"></a>
                           <a href="javascript:;" class="icon-remove"></a>
                           </span>                    
                        </div>
                        <div class="widget-body">
								<div class="span1"></div>
							<div class="span10">
                                <h4>TRACKING DETAILS<br/><small></small></h4>
                                <table class="table table-borderless">
                                    <tbody>
									<tr style="color:#c91010;"><td>TRACKING ID</td><td>LAST LOCATION</td><td>NEXT LOCATION</td><td>REMARKS</td></tr>
                                    
									   <!--td class="span2"><input type="number" name="cons_id" id="cons_id" min="0" placeholder="Consignment Id"></td><td><a href="#" class="btn btn-info"><i class="icon-map-marker"></i> GO</a></td -->
									</tbody>
									<tbody id="trackresp"></tbody>
                                </table>
								</div>
                            </div>
							

                            <div class="space5"></div>
                        </div>
						</div>
					</div>
			</div><!-- END PAGE CONTENT: profile-->
			
			
			</div>
      <!-- END PAGE -->  
   </div>
   <!-- END CONTAINER -->
   
			<script>
			function response()
			{
			}
	 function track()
	{
	 var datastr ='cons_method=track&awb='+ jQuery("#cons_id").val();
	 jQuery.ajax({
	 type:'POST',
	 data:datastr,
	 url: 'controller.php',
	 success: function(data) { 
	 jQuery("#tracktable").fadeIn();
	 jQuery('#trackresp').html(data);}
	 });
	 }
	// jQuery(document).ready(function(){("#tracktable").hide(); });
			</script>
			

<?php

include 'footer.php';
if(isset($_GET['cons_status']))
   {
echo "<script>track();</script>";
   }
   ?>

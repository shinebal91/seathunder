<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <title>Contact Us</title>

<?php
$group_id=2;
include 'header.php';
?>


         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     Contact Us
                     <small></small>
                  </h3>
                   <ul class="breadcrumb">
                       <li>
                           <a href="home.php"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
                       </li>
					   
					   <li>
                           <a href="contact-us.php">Contact Us</a><span class="divider-last">&nbsp;</span>
                       </li>
                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->
			
			
				<!-- BEGIN PAGE CONTENT-->
				<div id="page">
					<div class="row-fluid">
						<div class="span12">
							<!-- BEGIN BASIC PORTLET-->
							<div class="widget">
								<div class="widget-title">
									<h4><i class="icon-list-alt"></i> Contact Us</h4>
									<span class="tools">
									<a href="javascript:;" class="icon-chevron-down"></a>
									<a href="javascript:;" class="icon-remove"></a>
									</span>
								</div>
								<div class="widget-body">
									<!--div id="gmap_basic" class="gmaps"></div-->
                                    <div class="space20"></div>
                                    <!--BEGIN CONTACT US-->
                                    <div class="contact-us">
                                        <h3>Our Contacts</h3>
                                        <div class="row-fluid">
                                            <div class="span6">
                                                <h4 style="color:#c91010;">Location</h4>
                                                <p>SEBIZ SQUARE<br>
													Plot No. IT-C6, I.T.Park, Sector-67,<br>
													Sahibzada Ajit Singh Nagar,<br>
													Punjab 160062</p>
                                                    
                                            </div>
                                            <div class="span6">
                                                <h4 style="color:#c91010;">Online</h4>
                                                <p> <strong>Email :</strong> seathunder.logistics@gmail.com <br>
                                                    <!--strong>Support :</strong> support@seathunder.com<br>
                                                    <strong>Live Chat :</strong> live@seathunder.com--></p>
                                                
												
												<h4 style="color:#c91010;">Call Us At</h4>
                                                <p>
                                                    <strong>Phone:</strong> +91-172-306-8070								
												</p>
                                            </div>
                                            <div class="span4 hide">
                                                <h4 style="color:#c91010;">Call Us At</h4>
                                                <p>
                                                    <strong>Phone:</strong> +91-172-306-8070
													<!--strong>Facebook :</strong> www.facebook.com/seathunder<br>
                                                    <strong>Twitter :</strong> www.twitter.com/seathunder<br>
                                                    <strong>Google + :</strong> www.googleplus.com/seathunder<br-->
                                                </p>
                                            </div>
                                        </div>
                                        <div class="space20"></div>
                                        
										
										
                                    </div>
                                    <!--END CONTACT US-->
								</div>
							</div>
							<!-- END BASIC PORTLET-->
						</div>

					</div>

				</div>
				<!-- END PAGE CONTENT-->
			</div>
			<!-- END PAGE CONTAINER--> 			
		</div>
		<!-- END PAGE -->
	</div>
	<!-- END CONTAINER -->
	
	
	

<?php

include 'footer.php';

?>

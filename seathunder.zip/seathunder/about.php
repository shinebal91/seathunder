        <!-- About us section start -->
        <div class="section primary-section" id="about">
            <!--div class="triangle"></div-->
            <div class="container">
                <div class="title" style="border-bottom:#fff;">
                    <h1>ABOUT US</h1>
					<img src="images/logo.png"><br><br>
                    <p><span style="color:#006699;"><b>SeaThunder Logistics</b></span> provide a full array of ocean freight forwarding services right from door to door pick up, and managing shipping documents.
					Being an efficient international ocean freight forwarder, we provide comprehensive services to almost all seaport locations in more than 50 countries.
					We are committed to help organizations for consistent growth of their international trade. We understand that clients have specific needs as regards their shipments. Therefore, we spend considerable time discussing with our clients individually to understand their specific requirements and developing customized solutions. <br><br>
					<span style="color:#006699;"><b>MISSION: </b></span>To provide value-added, innovative, reliable & cost-effective logistic services to our customers.
					</p>
                </div>
                
                
                        
            </div>
        </div>
            </div>
        </div>
        <!-- About us section end -->
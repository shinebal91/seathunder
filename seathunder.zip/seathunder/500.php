<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   
   <title>500 Error</title>

   <meta charset="utf-8" />
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <meta content="" name="description" />
   <meta content="" name="author" />
   <link href="../configurations/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="../configurations/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   
   <link href="../configurations/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <!--link href="../configurations/css/style.css" rel="stylesheet" />
   <link href="../configurations/css/style_default.css" rel="stylesheet" id="style_color" /-->
   <link href="../configurations/css/style_responsive.css" rel="stylesheet" />
   
   <link rel="stylesheet" type="text/css" href="../configurations/assets/uniform/css/uniform.default.css" />
</head>
  
<body class="fixed-top">
<center>
   <!-- BEGIN HEADER -->
   <div id="header" class="navbar navbar-inverse navbar-fixed-top">
   </div>
   <!-- END HEADER -->
   
   <!-- BEGIN CONTAINER -->
	<div id="container" class="row-fluid">	  
      <!-- BEGIN PAGE -->  
      <div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
 
  
   <!-- BEGIN PAGE CONTENT-->
             <div class="row-fluid">
                 <div class="span12">
                     <div class="space20"></div>
                     <div class="space20"></div>
                     <div class="widget-body">
                         <div class="error-page">
								<br><br><br>
                             <img src="../images/500-small.jpg" alt="500 ERROR">
                             <h1>
                                 <strong><br><i class="icon-warning-sign"></i></strong> <br/>
                                 SERVER ERROR.!!<br><br>
								 <input type="button" name="goback" id="goback" class="btn btn-info" onclick="goback();"value="GO BACK">
                             </h1>
                         </div>
                     </div>
                 </div>
             </div>
            <!-- END PAGE CONTENT-->         
         </div>
         <!-- END PAGE CONTAINER-->
      </div>
      <!-- END PAGE -->  
   </div>
   <!-- END CONTAINER -->
 
 
   <!-- BEGIN JAVASCRIPTS -->    
   <!-- Load javascripts at bottom, this will reduce page load time -->
   <script src="../configurations/js/jquery-1.8.3.min.js"></script>
   <script src="../configurations/assets/bootstrap/js/bootstrap.min.js"></script>
   <script src="../configurations/js/jquery.blockui.js"></script>
   <!-- ie8 fixes -->
   <!--[if lt IE 9]>
   <script src="js/excanvas.js"></script>
   <script src="js/respond.js"></script>
   <![endif]-->
   <script type="text/javascript" src="../configurations/assets/chosen-bootstrap/chosen/chosen.jquery.min.js"></script>
   <script type="text/javascript" src="../configurations/assets/uniform/jquery.uniform.min.js"></script>
   <script src="../configurations/js/scripts.js"></script>
   <script>
      jQuery(document).ready(function() {       
         // initiate layout and plugins
         App.init();
      });
	  
	  function goback()
	  {
		  window.history.back();
		  
	  }
   </script>
   <!-- END JAVASCRIPTS -->   
</center>
</body>
<!-- END BODY -->
</html>
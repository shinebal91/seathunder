<?php
include('config.php');

if(isset($_POST['username']))
{
$username=$_POST['username'];
$username=stripslashes($username);
$username=mysqli_real_escape_string($con,$username);
$check="SELECT user_name from members where user_name='$username'";
$count=0;
$count=mysqli_num_rows(mysqli_query($con,$check));
//echo $count;
if($count>0)
{
echo '<p class="pull-center btn-danger" >Username Already Exists</p>';
}
else 
{
echo '<p class="pull-center btn-success" id="errors">Username Available</p>';
}
}

if(isset($_POST['email']))
{
$username=$_POST['email'];
$username=stripslashes($username);
$username=mysqli_real_escape_string($con,$username);
$check="SELECT email from members where email='$username'";
$count=0;
$count=mysqli_num_rows(mysqli_query($con,$check));
//echo $count;
if($count>0)
{
echo "<p class='btn-danger'>Email Already Exists</p>";
}
else 
{
echo "<p class='btn-success'>Email Available</p>";
}
}

?>
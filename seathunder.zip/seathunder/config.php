<?php
$con=mysqli_connect("localhost","root","prasan#mysql<3","seathunder");
 $GLOBALS['connect'] = $con;
?>

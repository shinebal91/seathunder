<?php
session_start();
if($_SESSION['user_id'] == '')
{
header('location:../login.php?err="Please Login First."');
}
//	echo $_SESSION['user_id'];
if($group_id != $_SESSION['grp_id'])
{
	
	include("500.php");
	exit(0);
}
?>
